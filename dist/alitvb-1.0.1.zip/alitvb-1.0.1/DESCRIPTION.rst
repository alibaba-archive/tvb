TVB is a python based command-line tool that you can do performance-testing for android smart television, TV box or phones.


