# TVB

TVB is a python based command-line tool that you can do performance-testing for android smart television, TV box or phones.

It integrate monkey tool to help you stress-test applications. And it collect performance and troubleshooting data through adb commands and generate an excel report with line charts. So that you can easily find out and analyze the problems. 

